package model;

// lớp Point được sử dụng để thực hiện các tính toán và xử lý liên quan đến các điểm trên mặt phẳng, 
// đặc biệt là việc tìm kiếm và xác định các điểm lân cận của một điểm cụ thể.

public class Point {
	public int x, y;
	
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	// Phương thức để tìm điểm bắt đầu theo trục x.
	public Point findStartXPoint() {
		int startX = x - 5 < 0 ? 0 : x - 5;	//Tính toán giá trị startX là x - 5, nếu x - 5 lớn hơn hoặc bằng 0, nếu không thì startX sẽ là 0.
		return new Point(startX, y);
	}
	// Phương thức để tìm điểm kết thúc theo trục x.
	public Point findEndXPoint() {
		int endX = x + 5 > 19 ? 19 : x + 5;	// Tính toán giá trị endX là x + 5, nếu x + 5 nhỏ hơn hoặc bằng 19, nếu không thì endX sẽ là 19.
		return new Point(endX, y);
	}
	//Phương thức để tìm điểm bắt đầu theo trục y.
	public Point findStartYPoint() {
		int startY = y - 5 < 0 ? 0 : y - 5;	//  Tính toán giá trị startY là y - 5 nếu y - 5 lớn hơn hoặc bằng 0, nếu không thì startY sẽ là 0.
		return new Point(x, startY);
	}
	// Phương thức để tìm điểm kết thúc theo trục y.
	public Point findEndYPoint() {
		int endY = y + 5 > 19 ? 19 : y + 5;	// Tính toán giá trị endY là y + 5 nếu y + 5 nhỏ hơn hoặc bằng 19, nếu không thì endY sẽ là 19.
		return new Point(x, endY);
	}
	// Phương thức để tìm điểm trên cùng bên trái.
	public Point findLeftTopPoint() {
		int startX = x - 5 < 0 ? 0 : x - 5;	// Tính toán giá trị startX và startY tương tự như trên.
		int startY = y - 5 < 0 ? 0 : y - 5;
		return new Point(startX, startY);
	}
	//  Phương thức để tìm điểm trên cùng bên phải.
	public Point findRightTopPoint() {
		int endX = x + 5 > 19 ? 19 : x + 5;	// Tính toán giá trị endX và startY tương tự như trên.
		int startY = y - 5 < 0 ? 0 : y - 5;
		return new Point(endX, startY);
	}
	// Phương thức để tìm điểm dưới cùng bên trái.
	public Point findLeftBottomPoint() {
		int startX = x - 5 < 0 ? 0 : x - 5;	// Tính toán giá trị startX và endY tương tự như trên.
		int endY = y + 5 > 19 ? 19 : y + 5;
		return new Point(startX, endY);
	}
	// Phương thức để tìm điểm dưới cùng bên phải.
	public Point findRightBottomPoint() {
		int endX = x + 5 > 19 ? 19 : x + 5;	// Tính toán giá trị endX và endY tương tự như trên.
		int endY = y + 5 > 19 ? 19 : y + 5;
		return new Point(endX, endY);
	}
	
	//Phương thức để in ra tọa độ của điểm.
	public void log() {
		System.out.println("x: "+ this.x + "| y: " + this.y);
	}
}
