package model;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;

//lớp XOButton được sử dụng để tạo ra các nút cho trò chơi Tic-Tac-Toe. 
//Mỗi nút có thể hiển thị biểu tượng X hoặc O dựa trên lượt đi hiện tại và lưu trữ giá trị tương ứng. 
//Nút cũng có khả năng nhận diện sự kiện chuột để thay đổi giao diện khi di chuột qua nút và xử lý lượt đi khi được nhấp chuột.

public class XOButton extends JButton { // Định nghĩa lớp XOButton, mở rộng từ lớp JButton để tạo ra một nút dùng cho
										// trò chơi Tic-Tac-Toe.
	private ImageIcon X;
	private ImageIcon O;
	public Point point;
	public static boolean isXMove = true; // Biến tĩnh để theo dõi lượt đi của X hoặc O.
	public int value = 0; // Giá trị của ô nút, được sử dụng để đại diện cho X (2) hoặc O (1).

	// constructor
	public XOButton(int x, int y) {
		X = new ImageIcon("assets/image/x3.jpg");
		O = new ImageIcon("assets/image/o3.jpg");
		setHorizontalAlignment(SwingConstants.CENTER);
		setVerticalAlignment(SwingConstants.CENTER);
		this.setIcon(new ImageIcon("assets/image/blank.jpg"));
		this.point = new Point(x, y);
		XOButton _this = this;	// Tạo một biến _this để truy cập vào nút trong các phương thức của MouseListener.
		this.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
				if (_this.isEnabled()) {
					_this.setBackground(null);
					_this.setIcon(new ImageIcon("assets/image/blank.jpg"));
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				if (_this.isEnabled()) {
					_this.setBackground(Color.GREEN);
					_this.setIcon(new ImageIcon("assets/image/x3.jpg"));
				}
			}

			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
	}
	
	// Phương thức để thiết lập trạng thái của nút, dựa trên lượt đi của X hoặc O.
	public void setState(Boolean isXMove) {
		if (isXMove) {	// Nếu isXMove là true, nút sẽ hiển thị biểu tượng X và có giá trị là 2.
			setIcon(X);
			value = 2;
			XOButton.isXMove = false;
			this.setDisabledIcon(X);
		} else {	// Nếu isXMove là false, nút sẽ hiển thị biểu tượng O và có giá trị là 1.
			setIcon(O);
			value = 1;
			this.setDisabledIcon(O);
			XOButton.isXMove = true;
		}
	}

	// Phương thức để đặt lại trạng thái của nút về trạng thái ban đầu.
	public void resetState() {
		value = 0;	// Giá trị của nút được đặt là 0.
		// Nút được kích hoạt và hiển thị hình ảnh ô trống.
		this.setEnabled(true);
		this.setIcon(new ImageIcon("assets/image/blank.jpg"));
		this.setDisabledIcon(new ImageIcon("assets/image/blank.jpg"));
	}

}