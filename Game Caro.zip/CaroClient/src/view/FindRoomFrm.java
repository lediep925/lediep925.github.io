package view;

import controller.Client;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

//tìm phòng chơi nhanh

public class FindRoomFrm extends javax.swing.JFrame {
	private Timer timer;
	private boolean isFinded;

	public FindRoomFrm() {
		initComponents();
		this.setTitle("Caro Game");
		this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		jLabel5.setIcon(new ImageIcon("assets/icon/loading1.gif"));
		jButton1.setIcon(new ImageIcon("assets/icon/door_exit.png"));
		jProgressBar1.setValue(70);
		isFinded = false;
		startFind();
		sendFindRequest();
	}

	// Phương thức để dừng tất cả các luồng (threads) đang chạy.
	public void stopAllThread() {
		timer.stop();// Dừng bộ hẹn giờ sử dụng để tìm phòng
	}

//  Bắt đầu tìm kiếm phòng chơi nhanh. 
//  Gọi phương thức này sẽ ẩn các nhãn và biểu tượng hiển thị thông tin tìm kiếm, bắt đầu đếm ngược thời gian và 
//  cập nhật tiến trình tìm kiếm trên thanh tiến trình. 
//  Nếu tìm kiếm không thành công, người dùng có thể chọn để tìm lại hoặc quay lại trang chủ.
	public void startFind() {
		jLabel4.setVisible(false);
		jLabel5.setVisible(false);
		timer = new Timer(1000, new ActionListener() {
			int count = 20;

			@Override
			public void actionPerformed(ActionEvent e) {
				count--;
				if (count >= 0) {
					if (count >= 10)
						jLabel3.setText("00:" + count);// Cập nhật nhãn đếm ngược
					else
						jLabel3.setText("00:0" + count);// Cập nhật nhãn đếm ngược với số 0 đứng đầu
					jProgressBar1.setValue(Math.round((float) count / 20 * 100));// Cập nhật thanh tiến trình
				} else {
					((Timer) (e.getSource())).stop();// Dừng bộ hẹn giờ
					try {
						Client.socketHandle.write("cancel-room,");// Gửi yêu cầu hủy tìm phòng
					} catch (IOException ex) {
						JOptionPane.showMessageDialog(rootPane, ex.getMessage());
					}
					int res = JOptionPane.showConfirmDialog(rootPane,
							"Tìm kiếm thất bại, bạn muốn thử lại lần nữa chứ?");// Hiển thị hộp thoại xác nhận để thử
																				// lại tìm phòng
					if (res == JOptionPane.YES_OPTION) {
						startFind();// Thử lại tìm phòng
						sendFindRequest();// Gửi yêu cầu tìm phòng
					} else {
						// Có thể hỏi chơi với máy không
						Client.closeView(Client.View.FINDROOM);// Đóng cửa sổ hiện tại
						Client.openView(Client.View.HOMEPAGE);// Mở cửa sổ trang chủ
					}
				}
			}
		});
		timer.setInitialDelay(0);// Đặt độ trễ ban đầu của bộ hẹn giờ là 0
		timer.start();// Bắt đầu bộ hẹn giờ
	}

//  Gửi yêu cầu tìm kiếm phòng chơi nhanh tới máy chủ.
	public void sendFindRequest() {
		try {
			Client.socketHandle.write("quick-room,");// Gửi yêu cầu tìm phòng đến máy chủ
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(rootPane, ex.getMessage());
		}
	}

//   Hiển thị thông tin về phòng chơi đã tìm thấy. Dừng đếm ngược và hiển thị thông báo tìm thấy phòng chơi.
	public void showFindedRoom() {
		isFinded = true;
		timer.stop();
		jLabel4.setVisible(true);
		jLabel5.setVisible(true);
		jLabel2.setVisible(false);

	}

	@SuppressWarnings("unchecked")
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jProgressBar1 = new javax.swing.JProgressBar();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jButton1 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));
		jProgressBar1.setBackground(new Color(255, 97, 139));
		jProgressBar1.setForeground(Color.black);
		jLabel1.setBackground(new java.awt.Color(255, 255, 255));
		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18));
		jLabel1.setForeground(new java.awt.Color(255, 97, 139));
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel1.setText("Tìm phòng nhanh");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addGap(29, 29, 29).addComponent(jLabel1)
						.addContainerGap(25, Short.MAX_VALUE)));

		jLabel2.setFont(new java.awt.Font("Tahoma", 2, 14));
		jLabel2.setText("Đang tìm đối thủ");

		jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14));
		jLabel3.setText("00:20");

		jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14));
		jLabel4.setForeground(new java.awt.Color(0, 51, 204));
		jLabel4.setText("Đã tìm thấy đối thủ, đang vào phòng");

		jButton1.setBackground(new Color(255,255,255));
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
						Short.MAX_VALUE)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
						.addContainerGap(53, Short.MAX_VALUE)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										layout.createSequentialGroup()
												.addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE,
														424, javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(51, 51, 51))
								.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
										layout.createSequentialGroup()
												.addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(239, 239, 239))
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
												layout.createSequentialGroup()
														.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE,
																113, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGap(200, 200, 200))
										.addGroup(layout.createSequentialGroup().addGap(89, 89, 89)
												.addComponent(jLabel4)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 43,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
														javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addContainerGap())))));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
				.createSequentialGroup()
				.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE)
				.addGap(30, 30, 30).addComponent(jLabel3)
				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jLabel2)
				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel4)
						.addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 41,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50,
								javax.swing.GroupLayout.PREFERRED_SIZE))
				.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pack();
	}

//  Xử lý sự kiện khi người dùng nhấn nút hủy. 
//  Gửi yêu cầu hủy tìm kiếm phòng chơi, dừng đếm ngược và đóng giao diện hiện tại, sau đó mở giao diện trang chủ.
	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		if (isFinded)
			return;
		try {
			Client.socketHandle.write("cancel-room,");
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(rootPane, ex.getMessage());
		}
		timer.stop();
		Client.closeView(Client.View.FINDROOM);
		Client.openView(Client.View.HOMEPAGE);
	}

	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JProgressBar jProgressBar1;
}