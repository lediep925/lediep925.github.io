package view;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import controller.Client;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.User;

public class RegisterFrm extends javax.swing.JFrame {

    public RegisterFrm() {
        initComponents();
        this.setTitle("Caro Game");
        this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        avatarComboBox1.setMaximumRowCount(7);
        for (int i=0; i<=7; i++) {
            avatarComboBox1.addItem(new ImageIcon("assets/avatar/"+i+".jpg"));
        }
    }

 // Cấu hình các thành phần giao diện và sự kiện
    @SuppressWarnings("unchecked")
   private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jTextField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        jTextField1.setBounds(145, 98, 120, 19);
        jTextField2 = new javax.swing.JTextField();
        jTextField2.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        jTextField2.setBounds(145, 177, 120, 19);
        jLabel2 = new javax.swing.JLabel();
        jLabel2.setFont(new Font("Tahoma", Font.BOLD, 10));
        jLabel2.setBounds(40, 101, 56, 13);
        jLabel3 = new javax.swing.JLabel();
        jLabel3.setFont(new Font("Tahoma", Font.BOLD, 10));
        jLabel3.setBounds(40, 140, 56, 13);
        jLabel4 = new javax.swing.JLabel();
        jLabel4.setFont(new Font("Tahoma", Font.BOLD, 10));
        jLabel4.setBounds(40, 180, 56, 13);
        jButton1 = new javax.swing.JButton();
        jButton1.setForeground(new Color(255, 255, 255));
        jButton1.setFont(new Font("Tahoma", Font.BOLD, 10));
        jButton1.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
        jButton1.setBackground(new java.awt.Color(35,31,40));
        jButton1.setBounds(120, 324, 89, 21);
        jLabel5 = new javax.swing.JLabel();
        jLabel5.setFont(new Font("Tahoma", Font.BOLD, 10));
        jLabel5.setBounds(77, 355, 199, 13);
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        jPasswordField1.setBounds(145, 137, 120, 19);
        jPanel1 = new javax.swing.JPanel();
        jPanel1.setBounds(0, 0, 322, 67);
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel6.setFont(new Font("Tahoma", Font.BOLD, 10));
        jLabel6.setBounds(40, 223, 73, 13);
        avatarComboBox1 = new javax.swing.JComboBox<>();
        avatarComboBox1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        avatarComboBox1.setBounds(145, 223, 120, 75);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBackground(new java.awt.Color(48, 46, 43));
        setForeground(new java.awt.Color(48, 46, 43));
        setPreferredSize(new java.awt.Dimension(330, 410));
        setResizable(false);

        jLabel2.setText("Tài Khoản");

        jLabel3.setText("Mật Khẩu");

        jLabel4.setText("NickName");

        jButton1.setText("Đăng kí");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Đã có tài khoản, đăng nhập tại đây");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(36,36,46));

        jLabel1.setFont(new Font("Tahoma", Font.BOLD, 18)); 
        jLabel1.setForeground(new java.awt.Color(255, 97,139));
        jLabel1.setText("Đăng Kí");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(123, 123, 123)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(20, 20, 20))
        );

        jLabel6.setText("Chọn Avatar");
        getContentPane().setLayout(null);
        getContentPane().add(jPanel1);
        getContentPane().add(jLabel5);
        getContentPane().add(jLabel2);
        getContentPane().add(jLabel3);
        getContentPane().add(jLabel4);
        getContentPane().add(jLabel6);
        getContentPane().add(avatarComboBox1);
        getContentPane().add(jTextField1);
        getContentPane().add(jPasswordField1);
        getContentPane().add(jTextField2);
        getContentPane().add(jButton1);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("assets\\bgr\\bg4.png"));
        lblNewLabel.setBounds(0, 0, 322, 373);
        getContentPane().add(lblNewLabel);

        pack();
    }

 // Xử lý sự kiện nhấp chuột vào chữ "Đã có tài khoản, đăng nhập tại đây"
    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {
        Client.closeView(Client.View.REGISTER);
        Client.openView(Client.View.LOGIN);
    }

 // Xử lý sự kiện nhấn nút "Đăng kí"
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String username = jTextField1.getText();
            if(username.isEmpty())
                throw new Exception("Vui lòng nhập tên tài khoản");
            String password = String.copyValueOf(jPasswordField1.getPassword());
            if(password.isEmpty())
                throw new Exception("Vui lòng nhập mật khẩu");
            String nickName = jTextField2.getText();
            int avatar = avatarComboBox1.getSelectedIndex();
            if(avatar==-1){
                throw new Exception("Vui lòng chọn avatar");
            }
            if(nickName.isEmpty())
                throw new Exception("Vui lòng nhập nickname");
            
         // Thực hiện đăng ký tài khoản
            Client.closeAllViews();
            Client.openView(Client.View.GAMENOTICE, "Đăng kí tài khoản", "Đang chờ phản hồi");
            Client.socketHandle.write("register,"+username+","+password+","+nickName+","+avatar);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }

    private javax.swing.JComboBox<ImageIcon> avatarComboBox1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
}