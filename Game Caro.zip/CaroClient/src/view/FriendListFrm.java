package view;
import controller.Client;

import java.awt.Color;
import java.io.IOException;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import model.User;

// hiển thị danh sách bạn bè

public class FriendListFrm extends javax.swing.JFrame {
    private List<User> listFriend;
    private boolean isClicked;
    private Thread thread;
    DefaultTableModel defaultTableModel;

    public FriendListFrm() {
        initComponents();
        defaultTableModel = (DefaultTableModel) jTable1.getModel();
        this.setTitle("Caro Game");
        this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        isClicked = false;
        requestUpdate();
        startThread();
    }
    
    // Dừng tất cả các luồng.
    public void stopAllThread(){
       isClicked=true;
    }
    
    // Khởi động một luồng để cập nhật danh sách bạn bè trong thời gian thực. 
    // Luồng sẽ gửi yêu cầu cập nhật danh sách bạn bè và cập nhật danh sách sau mỗi 500ms.
    public void startThread(){
        thread = new Thread() {
            @Override
            public void run() {
                while (Client.friendListFrm.isDisplayable()&&!isClicked) {
                    try {
                        System.out.println("Xem danh sách bạn bè đang chạy!");
                        requestUpdate();
                        Thread.sleep(500);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        };
        thread.start();
    }
    
    // Gửi yêu cầu cập nhật danh sách bạn bè tới máy chủ
    public void requestUpdate(){
        try {
            Client.socketHandle.write("view-friend-list,");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }
    
    // Cập nhật danh sách bạn bè trên giao diện. Danh sách bạn bè được truyền dưới dạng một danh sách các đối tượng User. Các thông tin về bạn bè được hiển thị trong bảng, bao gồm ID, nickname và biểu tượng (icon) tương ứng với trạng thái trực tuyến và trạng thái chơi game của bạn bè.
    public void updateFriendList(List<User> friends){
        listFriend = friends;
        defaultTableModel.setRowCount(0);
        ImageIcon icon;
        for(User friend : listFriend){
            if(!friend.isIsOnline()){
                icon = new ImageIcon("assets/icon/offline.png");
            }
            else if(friend.isIsPlaying()){
                icon = new ImageIcon("assets/icon/swords-mini.png");
            }
            else{
                icon = new ImageIcon("assets/icon/swords-1-mini.png");
            }
            defaultTableModel.addRow(new Object[]{
                ""+friend.getID(),
                friend.getNickname(),
                icon
            });
        }
    }
    
    
    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        Object[][] rows = {
        };
        String[] columns = {"ID","Nickname",""};
        DefaultTableModel model = new DefaultTableModel(rows, columns){
            @Override
            public Class<?> getColumnClass(int column){
                switch(column){
                    case 0: return String.class;
                    case 1: return String.class;
                    case 2: return ImageIcon.class;
                    default: return Object.class;
                }
            }
        };
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255,255,255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jLabel1.setForeground(new java.awt.Color(255,97,139));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Danh sách bạn bè");

        jButton1.setText("X");
        jButton1.setBackground(new Color(255,97,139));
        jButton1.setForeground(Color.white);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jTable1.setModel(model);
        jTable1.setRowHeight(60);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setMinWidth(60);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(60);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(60);
            jTable1.getColumnModel().getColumn(1).setMinWidth(240);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(240);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(240);
            jTable1.getColumnModel().getColumn(2).setMinWidth(120);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(120);
            jTable1.getColumnModel().getColumn(2).setMaxWidth(120);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }

 // Xử lý sự kiện nhấn nút "X" để đóng giao diện danh sách bạn bè
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.closeView(Client.View.FRIENDLIST);
        Client.openView(Client.View.HOMEPAGE);
    }

    // Xử lý sự kiện nhấp chuột vào một hàng trong bảng danh sách bạn bè
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {
        try {
            if(jTable1.getSelectedRow()==-1) return;
            User friend = listFriend.get(jTable1.getSelectedRow());
            if(!friend.isIsOnline()){
                throw new Exception("Người chơi không online");
            }
            if(friend.isIsPlaying()){
                throw new Exception("Người chơi đang trong trận đấu");
            }
            isClicked = true;
            int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn thách đấu người bạn này không", "Xác nhận thách đầu", JOptionPane.YES_NO_OPTION);
            if(res == JOptionPane.YES_OPTION){
            	// Gửi yêu cầu thách đấu
                Client.closeAllViews();
                Client.openView(Client.View.GAMENOTICE, "Thách đấu", "Đang chờ phản hồi từ đối thủ");
                Client.socketHandle.write("duel-request,"+friend.getID());
            }
            else{
                isClicked = false;
                startThread();
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
}