package view;
import controller.Client;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import model.User;

public class RankFrm extends javax.swing.JFrame {
    private DefaultTableModel tableModel;	// quản lý dữ liệu của bảng xếp hạng.
    private List<User> listUserStatics;	//  danh sách các đối tượng User đại diện cho thông tin người chơi trong bảng xếp hạng.
    private List<String> rankSrc;	//danh sách các tên tệp hình ảnh biểu tượng đại diện cho các hạng trong bảng xếp hạng.

    public RankFrm() {
        initComponents();
        this.setTitle("Caro Game");
        tableModel = (DefaultTableModel) jTable1.getModel();
        this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        rankSrc = new ArrayList<>();
        rankSrc.add("rank-gold");
        rankSrc.add("rank-sliver");
        rankSrc.add("bronze-rank");
        for(int i=0; i<5; i++){
            rankSrc.add("nomal-rank");
        }
        try {
            Client.socketHandle.write("get-rank-charts,");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }
    
    // Phương thức để cung cấp dữ liệu người chơi vào bảng xếp hạng.
    public void setDataToTable(List<User> users){
        this.listUserStatics = users;
        tableModel.setRowCount(0);
        int i=0;
        for(User user : listUserStatics){
            tableModel.addRow(new Object[]{
                i+1,
                user.getNickname(),
                new ImageIcon("assets/icon/"+rankSrc.get(i)+".png")
            });
            i++;
        }

    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Object[][] rows = {
        };
        String[] columns = {"Nickname","Điểm","Rank"};
        DefaultTableModel model = new DefaultTableModel(rows, columns){
            @Override
            public Class<?> getColumnClass(int column){
                switch(column){
                    case 0: return String.class;
                    case 1: return String.class;
                    case 2: return ImageIcon.class;
                    default: return Object.class;
                }
            }
        };
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255,255,255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jLabel1.setForeground(new java.awt.Color(255, 97,139));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Bảng xếp hạng");

        jTable1.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jTable1.setModel(model);
        jTable1.setFillsViewportHeight(true);
        jTable1.setRowHeight(62);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 363, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 531, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }

//    Khi người dùng nhấp chuột vào một dòng trong bảng, sự kiện jTable1MouseClicked được xử lý để 
//    hiển thị thông tin chi tiết của người chơi được chọn hoặc hiển thị thứ hạng của người dùng hiện tại.
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {
        if(jTable1.getSelectedRow()==-1)
            return;
        if(listUserStatics.get(jTable1.getSelectedRow()).getID()==Client.user.getID()){
            JOptionPane.showMessageDialog(rootPane, "Thứ hạng của bạn là "+(jTable1.getSelectedRow()+1));
            return;
        }
        Client.openView(Client.View.COMPETITORINFO,listUserStatics.get(jTable1.getSelectedRow()));
    }


    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
}