package view;

import controller.Client;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.User;

//hiển thị thông tin của đối thủ

public class CompetitorInfoFrm extends javax.swing.JFrame {
	private boolean isFriend;	// kiểm tra trạng thái bạn bè của người dùng hiện tại.
    private User user;	// Đối tượng User đại diện cho đối thủ.

	public CompetitorInfoFrm(User user) {
		try {
			initComponents();
			this.user = user;
			this.setTitle("Caro Game");
			this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
			this.setResizable(false);
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			this.setLocationRelativeTo(null);
			jLabel6.setIcon(new ImageIcon("assets/game/" + user.getAvatar() + ".jpg"));
			jLabel7.setText(user.getNickname());
			jLabel8.setText("" + user.getNumberOfGame());
			jLabel9.setText("" + user.getNumberOfwin());
			jLabel17.setText("" + user.getNumberOfDraw());
			jLabel13.setText("" + user.getRank());
			if (user.getNumberOfGame() == 0) {
				jLabel15.setText("-");
			} else {
				jLabel15.setText(
						String.format("%.2f", (float) user.getNumberOfwin() / user.getNumberOfGame() * 100) + "%");
			}
			jLabel12.setText("" + (user.getNumberOfwin() * 10 + user.getNumberOfGame()));
			Client.socketHandle.write("check-friend," + user.getID());
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(rootPane, ex.getMessage());
		}
	}
	
//  Kiểm tra và cấu hình trạng thái bạn bè. Thay đổi biểu tượng và nhãn hiển thị tùy thuộc vào trạng thái bạn bè.
	public void checkFriend(boolean isFriend) {
		this.isFriend = isFriend;
		if (isFriend) {
			jButton1.setIcon(new ImageIcon("assets/icon/friendship.png"));
			jButton1.setToolTipText("Bạn bè");
			jLabel5.setText("Bạn bè");

		} else {
			jButton1.setIcon(new ImageIcon("assets/icon/add-friend.png"));
			jButton1.setToolTipText("Click để gửi yêu cầu kết bạn");
			jLabel5.setText("Kết bạn để chơi cùng nhau dễ dàng hơn");
		}
	}

	@SuppressWarnings("unchecked")
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel1.setBounds(0, 0, 296, 61);
		jLabel1 = new javax.swing.JLabel();
		jLabel1.setBounds(0, 20, 301, 22);
		jButton1 = new javax.swing.JButton();
		jButton1.setBounds(169, 79, 65, 70);
		jLabel2 = new javax.swing.JLabel();
		jLabel2.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel2.setBounds(73, 198, 69, 13);
		jLabel3 = new javax.swing.JLabel();
		jLabel3.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel3.setBounds(73, 221, 69, 13);
		jLabel4 = new javax.swing.JLabel();
		jLabel4.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel4.setBounds(73, 244, 78, 13);
		jLabel5 = new javax.swing.JLabel();
		jLabel5.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel5.setBounds(0, 380, 289, 13);
		jLabel6 = new javax.swing.JLabel();
		jLabel6.setBackground(new Color(255,255,255));
		jLabel6.setBounds(60, 79, 65, 70);
		jLabel7 = new javax.swing.JLabel();
		jLabel7.setBounds(169, 198, 110, 13);
		jLabel8 = new javax.swing.JLabel();
		jLabel8.setBounds(169, 221, 90, 13);
		jLabel9 = new javax.swing.JLabel();
		jLabel9.setBounds(169, 244, 90, 13);
		jLabel10 = new javax.swing.JLabel();
		jLabel10.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel10.setBounds(73, 309, 40, 13);
		jLabel11 = new javax.swing.JLabel();
		jLabel11.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel11.setBounds(73, 332, 67, 13);
		jLabel12 = new javax.swing.JLabel();
		jLabel12.setBounds(169, 309, 63, 13);
		jLabel13 = new javax.swing.JLabel();
		jLabel13.setBounds(169, 332, 63, 13);
		jLabel14 = new javax.swing.JLabel();
		jLabel14.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel14.setBounds(73, 286, 67, 13);
		jLabel15 = new javax.swing.JLabel();
		jLabel15.setBounds(169, 286, 63, 13);
		jLabel16 = new javax.swing.JLabel();
		jLabel16.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel16.setBounds(73, 267, 78, 13);
		jLabel17 = new javax.swing.JLabel();
		jLabel17.setBounds(169, 267, 72, 13);

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setBackground(new java.awt.Color(48, 46, 43));
		setForeground(new java.awt.Color(48, 46, 43));
		setPreferredSize(new java.awt.Dimension(310, 440));
		setResizable(false);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(Color.black);
		jPanel1.setForeground(new java.awt.Color(102, 102, 102));

		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
		jLabel1.setForeground(new java.awt.Color(225, 97, 139));
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel1.setText("Thông tin đối thủ");

		jButton1.setBackground(new Color(255,97,139));
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jLabel2.setText("Nickname");

		jLabel3.setText("Số ván chơi");

		jLabel4.setText("Số ván thắng");

		jLabel5.setForeground(new java.awt.Color(0, 51, 255));
		jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel5.setText("Các bạn hiện đang là bạn bè");

		jLabel7.setText("{nickname}");

		jLabel8.setText("{sovachoi}");

		jLabel9.setText("{sovanthang}");

		jLabel10.setText("Điểm");

		jLabel11.setText("Thứ hạng");

		jLabel12.setText("{diem}");

		jLabel13.setText("{thuhang}");

		jLabel14.setText("Tỉ lệ thắng");

		jLabel15.setText("{tillethang}");

		jLabel16.setText("Số ván hòa");

		jLabel17.setText("{sovanhoa}");

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("assets\\bgr\\bg2.png"));
		lblNewLabel.setBounds(0, 58, 296, 345);
		jPanel1.setLayout(null);
		jPanel1.add(jLabel1);
		getContentPane().setLayout(null);
		getContentPane().add(jLabel5);
		getContentPane().add(jLabel6);
		getContentPane().add(jLabel3);
		getContentPane().add(jLabel4);
		getContentPane().add(jLabel2);
		getContentPane().add(jLabel14);
		getContentPane().add(jLabel11);
		getContentPane().add(jLabel10);
		getContentPane().add(jLabel16);
		getContentPane().add(jLabel9);
		getContentPane().add(jLabel8);
		getContentPane().add(jButton1);
		getContentPane().add(jLabel15);
		getContentPane().add(jLabel13);
		getContentPane().add(jLabel12);
		getContentPane().add(jLabel7);
		getContentPane().add(jLabel17);
		getContentPane().add(jPanel1);
		getContentPane().add(lblNewLabel);

		pack();
	}

//  Xử lý sự kiện khi người dùng nhấn nút. 
//  Kiểm tra trạng thái bạn bè và hiển thị thông báo tương ứng hoặc gửi yêu cầu kết bạn đến đối thủ.
	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		if (isFriend) {
			JOptionPane.showMessageDialog(rootPane, "Bạn và đối thủ đang là bạn bè");
		} else {
			int res = JOptionPane.showConfirmDialog(rootPane, "Bạn đồng ý gửi lời mời kết bạn tới đối thủ chứ",
					"Xác nhận yêu cầu kết bạn", JOptionPane.YES_NO_OPTION);
			if (res == JOptionPane.YES_OPTION) {
				try {
					Client.socketHandle.write("make-friend," + user.getID());
				} catch (IOException ex) {
					JOptionPane.showMessageDialog(rootPane, ex.getMessage());
				}
			}
		}
	}

	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;

}