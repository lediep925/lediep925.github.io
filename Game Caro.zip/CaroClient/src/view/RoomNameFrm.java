package view;

import controller.Client;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

// nhập tên phòng và mật khẩu phòng trước khi vào phòng chơi

public class RoomNameFrm extends javax.swing.JFrame {

    public RoomNameFrm() {
        initComponents();
         this.setTitle("Caro Game");
        this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        jLabel3.setVisible(false);
    }

    @SuppressWarnings("unchecked")
     private void initComponents() {

	        jPanel1 = new javax.swing.JPanel();
	        jPanel1.setBounds(0, 0, 356, 52);
	        jLabel1 = new javax.swing.JLabel();
	        jTextField1 = new javax.swing.JTextField();
	        jTextField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
	        jTextField1.setBounds(146, 68, 159, 22);
	        jLabel2 = new javax.swing.JLabel();
	        jLabel2.setFont(new Font("Tahoma", Font.BOLD, 11));
	        jLabel2.setForeground(Color.white);
	        jLabel2.setBounds(40, 72, 98, 13);
	        jButton1 = new javax.swing.JButton();
	        jButton1.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton1.setBackground(new java.awt.Color(35,31,40));
	        jButton1.setForeground(new java.awt.Color(255, 255, 255));
	        jButton1.setBounds(120, 168, 115, 24);
	        jLabel3 = new javax.swing.JLabel();
	        jLabel3.setBounds(128, 210, 98, 13);
	        jLabel4 = new javax.swing.JLabel();
	        jLabel4.setFont(new Font("Tahoma", Font.BOLD, 11));
	        jLabel4.setForeground(Color.white);
	        jLabel4.setBounds(40, 116, 98, 13);
	        jTextField2 = new javax.swing.JTextField();
	        jTextField2.setBorder(BorderFactory.createLineBorder(Color.WHITE));
	        jTextField2.setBounds(146, 112, 159, 22);
	        jLabel5 = new javax.swing.JLabel();
	        jLabel5.setBounds(88, 146, 250, 14);
	        jLabel5.setForeground(Color.white);
	        jLabel5.setForeground(Color.white);
	        
	        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBackground(new java.awt.Color(48, 46, 43));
	        setForeground(new java.awt.Color(48, 46, 43));
	        setPreferredSize(new java.awt.Dimension(370, 270));
	        setResizable(false);

	        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

	        jPanel1.setBackground(Color.black);

	        jLabel1.setFont(new Font("Segoe UI", Font.BOLD, 24)); 
	        jLabel1.setForeground(new java.awt.Color(255, 97,139));
	        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
	        jLabel1.setText("Vào phòng");

	        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jLabel1)
	                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );

	        jTextField1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jTextField1ActionPerformed(evt);
	            }
	        });

	        jLabel2.setText("Nhập mã phòng");

	        jButton1.setText("Vào phòng");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton1ActionPerformed(evt);
	            }
	        });

	        jLabel3.setForeground(new java.awt.Color(0, 51, 255));
	        jLabel3.setText("Đang tìm kiếm phòng");

	        jLabel4.setText("Mật khẩu phòng");

	        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 10)); 
	        jLabel5.setText("Nếu phòng không có mật khẩu hãy để trống");
	        getContentPane().setLayout(null);
	        getContentPane().add(jPanel1);
	        getContentPane().add(jLabel4);
	        getContentPane().add(jLabel2);
	        getContentPane().add(jTextField1);
	        getContentPane().add(jTextField2);
	        getContentPane().add(jLabel5);
	        getContentPane().add(jButton1);
	        getContentPane().add(jLabel3);
	        
	        lblNewLabel = new JLabel("\r\n");
	        lblNewLabel.setIcon(new ImageIcon("assets\\bgr\\bg6.png"));
	        lblNewLabel.setBounds(0, 10, 356, 233);
	        getContentPane().add(lblNewLabel);

	        pack();
	    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Vào phòng"
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        String roomName = jTextField1.getText();
        if(roomName.equals("")){
            JOptionPane.showMessageDialog(rootPane, "Vui lòng nhập mã phòng");
            return;
        }
        try {
            String password = " ";
            if(jTextField2.getText().length()>0){
                password = jTextField2.getText();
            }
         // Gửi yêu cầu vào phòng với tên phòng và mật khẩu
            Client.socketHandle.write("go-to-room,"+roomName+","+password);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }


    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private JLabel lblNewLabel;
}