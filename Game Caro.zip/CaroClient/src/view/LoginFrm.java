package view;

import controller.Client;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.User;

public class LoginFrm extends javax.swing.JFrame {
	
	public LoginFrm() {
		initComponents();
		// Cấu hình giao diện
		this.setTitle("Caro Game");
		this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
	}

	public LoginFrm(String taiKhoan, String matKhau) {
		initComponents();
		jPasswordField1.setText(matKhau);
		jTextField1.setText(taiKhoan);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
	}

	// Hiển thị thông báo lỗi
	public void showError(String message) {
		JOptionPane.showMessageDialog(rootPane, message);
	}

	// Hiển thị thông báo đăng nhập thành công
	public void log(String message) {
		JOptionPane.showMessageDialog(rootPane, "ID của server thread là:" + message);
	}

	// Cấu hình các thành phần giao diện và sự kiện
	@SuppressWarnings("unchecked")
	private void initComponents() {
		
		jTextField1 = new javax.swing.JTextField();
		jTextField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		jTextField1.setBounds(171, 67, 146, 19);
		jLabel1 = new javax.swing.JLabel();
		jLabel1.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel1.setBounds(57, 70, 64, 13);
		jLabel2 = new javax.swing.JLabel();
		jLabel2.setFont(new Font("Tahoma", Font.BOLD, 10));
		jLabel2.setBounds(60, 109, 61, 13);
		jPasswordField1 = new javax.swing.JPasswordField();
		jPasswordField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		jPasswordField1.setBounds(171, 106, 146, 19);
		jButton1 = new javax.swing.JButton();
		jButton1.setForeground(new Color(255, 255, 255));
		jButton1.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35, 31, 40)));
		jButton1.setBackground(new java.awt.Color(35, 31, 40));
		jButton1.setFont(new Font("Tahoma", Font.BOLD, 10));
		jButton1.setBounds(144, 157, 100, 21);
		jButton2 = new javax.swing.JButton();
		jButton2.setForeground(new Color(255, 255, 255));
		jButton2.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35, 31, 40)));
		jButton2.setBackground(new java.awt.Color(35, 31, 40));
		jButton2.setFont(new Font("Tahoma", Font.BOLD, 10));
		jButton2.setBounds(144, 202, 100, 21);
		jPanel1 = new javax.swing.JPanel();
		jPanel1.setBounds(0, 0, 386, 52);
		jLabel3 = new javax.swing.JLabel();
		jLabel3.setBounds(147, 15, 114, 22);
		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setBackground(new java.awt.Color(48, 46, 43));
		setForeground(new java.awt.Color(48, 46, 43));
		setPreferredSize(new java.awt.Dimension(400, 300));
		setResizable(false);
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel1.setText("Tài khoản");

		jLabel2.setText("Mật khẩu");

		jButton1.setText("Đăng Nhập");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton2.setText("Đăng kí");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jPanel1.setBackground(new java.awt.Color(36, 36, 46));

		jLabel3.setFont(new Font("Tahoma", Font.BOLD, 18));
		jLabel3.setForeground(new java.awt.Color(255, 97, 139));
		jLabel3.setText("Đăng Nhập");
		getContentPane().setLayout(null);
		getContentPane().add(jPanel1);
		jPanel1.setLayout(null);
		jPanel1.add(jLabel3);
		getContentPane().add(jLabel1);
		getContentPane().add(jLabel2);
		getContentPane().add(jTextField1);
		getContentPane().add(jPasswordField1);
		getContentPane().add(jButton2);
		getContentPane().add(jButton1);

		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("assets\\bgr\\bg5.png"));
		lblNewLabel.setBounds(0, 0, 386, 263);
		getContentPane().add(lblNewLabel);

		pack();
	}

	// Xử lý sự kiện nhấn nút "Đăng Nhập"
	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			String taiKhoan = jTextField1.getText();
			if (taiKhoan.isEmpty())
				throw new Exception("Vui lòng nhập tên tài khoản");
			String matKhau = String.copyValueOf(jPasswordField1.getPassword());
			if (matKhau.isEmpty())
				throw new Exception("Vui lòng nhập mật khẩu");
			
			// Thực hiện xác thực thông tin đăng nhập
			Client.closeAllViews();
			Client.openView(Client.View.GAMENOTICE, "Đăng nhập", "Đang xác thực thông tin đăng nhập");
			Client.socketHandle.write("client-verify," + taiKhoan + "," + matKhau);
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(rootPane, ex.getMessage());
		}
	}

	// Xử lý sự kiện nhấn nút "Đăng kí"
	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		Client.closeView(Client.View.LOGIN);
		Client.openView(Client.View.REGISTER);
	}

	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPasswordField jPasswordField1;
	private javax.swing.JTextField jTextField1;
	private JLabel lblNewLabel;
}