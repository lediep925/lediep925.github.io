package view;

import controller.Client;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;



public class HomePageFrm extends javax.swing.JFrame {
    public HomePageFrm() {
        initComponents();
        this.setTitle("Caro Game");
        this.setIconImage(new ImageIcon("assets/image/caroicon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        jLabel4.setText(Client.user.getNickname());
        jLabel7.setText(Integer.toString(Client.user.getNumberOfwin()));
        jLabel9.setText(Integer.toString(Client.user.getNumberOfGame()));
        jLabel8.setIcon(new ImageIcon("assets/avatar/"+Client.user.getAvatar()+".jpg"));
        jButton10.setIcon(new ImageIcon("assets/image/send2.png"));
        jTextArea1.setEditable(false);
        
        if(Client.user.getNumberOfGame()==0){
            jLabel14.setText("-");
        }
        else{
            jLabel14.setText(String.format("%.2f", (float)Client.user.getNumberOfwin()/Client.user.getNumberOfGame()*100)+"%");
        }
        jLabel16.setText(""+Client.user.getNumberOfDraw());
        jLabel10.setText(""+(Client.user.getNumberOfGame()+Client.user.getNumberOfwin()*10));
        jLabel12.setText(""+Client.user.getRank());
    }

    @SuppressWarnings("unchecked")
 private void initComponents() {

	        jLayeredPane1 = new javax.swing.JLayeredPane();
	        jLabel2 = new javax.swing.JLabel();
	        jLabel2.setBounds(10, 10, 406, 32);
	        jButton1 = new javax.swing.JButton();
	        jButton1.setForeground(new Color(255, 255, 255));
	        jButton1.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton1.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton1.setBackground(new java.awt.Color(35,31,40));
	        jButton1.setBounds(294, 368, 98, 21);
	        jButton3 = new javax.swing.JButton();
	        jButton3.setForeground(new Color(255, 255, 255));
	        jButton3.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton3.setBackground(new java.awt.Color(35,31,40));
	        jButton3.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton3.setBounds(28, 465, 99, 21);
	        jButton4 = new javax.swing.JButton();
	        jButton4.setForeground(new Color(255, 255, 255));
	        jButton4.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton4.setBackground(new java.awt.Color(35,31,40));
	        jButton4.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton4.setBounds(28, 418, 98, 21);
	        jPanel1 = new javax.swing.JPanel();
	        jPanel1.setBounds(34, 52, 353, 145);
	        jLabel1 = new javax.swing.JLabel();
	        jLabel1.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel1.setBounds(150, 10, 60, 13);
	        jLabel3 = new javax.swing.JLabel();
	        jLabel3.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel3.setBounds(150, 57, 80, 13);
	        jLabel4 = new javax.swing.JLabel();
	        jLabel4.setBounds(240, 10, 114, 13);
	        jLabel7 = new javax.swing.JLabel();
	        jLabel7.setBounds(240, 57, 114, 13);
	        jLabel8 = new javax.swing.JLabel();
	        jLabel8.setBounds(14, 23, 100, 100);
	        jLabel9 = new javax.swing.JLabel();
	        jLabel9.setBounds(240, 34, 114, 13);
	        jLabel5 = new javax.swing.JLabel();
	        jLabel5.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel5.setBounds(150, 34, 95, 13);
	        jLabel6 = new javax.swing.JLabel();
	        jLabel6.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel6.setBounds(150, 126, 34, 13);
	        jLabel10 = new javax.swing.JLabel();
	        jLabel10.setBounds(240, 126, 114, 13);
	        jLabel10.setBackground(Color.black);
	        jLabel11 = new javax.swing.JLabel();
	        jLabel11.setBounds(167, 149, 77, 13);
	        jLabel12 = new javax.swing.JLabel();
	        jLabel12.setBounds(280, 149, 90, 13);
	        jLabel13 = new javax.swing.JLabel();
	        jLabel13.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel13.setBounds(150, 103, 77, 13);
	        jLabel14 = new javax.swing.JLabel();
	        jLabel14.setBounds(240, 103, 90, 13);
	        jLabel15 = new javax.swing.JLabel();
	        jLabel15.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jLabel15.setBounds(150, 80, 77, 13);
	        jLabel16 = new javax.swing.JLabel();
	        jLabel16.setBounds(240, 80, 90, 13);
	        jButton2 = new javax.swing.JButton();
	        jButton2.setForeground(new Color(255, 255, 255));
	        jButton2.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton2.setBackground(new java.awt.Color(35,31,40));
	        jButton2.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton2.setBounds(162, 465, 98, 21);
	        jButton5 = new javax.swing.JButton();
	        jButton5.setForeground(new Color(255, 255, 255));
	        jButton5.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton5.setBackground(new java.awt.Color(35,31,40));
	        jButton5.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton5.setBounds(294, 465, 98, 21);
	        jButton6 = new javax.swing.JButton();
	        jButton6.setForeground(new Color(255, 255, 255));
	        jButton6.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton6.setBackground(new java.awt.Color(35,31,40));
	        jButton6.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton6.setBounds(28, 368, 98, 21);
	        jButton7 = new javax.swing.JButton();
	        jButton7.setForeground(new Color(255, 255, 255));
	        jButton7.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton7.setBackground(new java.awt.Color(35,31,40));
	        jButton7.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton7.setBounds(162, 418, 98, 21);
	        jButton8 = new javax.swing.JButton();
	        jButton8.setForeground(new Color(255, 255, 255));
	        jButton8.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton8.setBackground(new java.awt.Color(35,31,40));
	        jButton8.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton8.setBounds(294, 418, 98, 21);
	        jButton9 = new javax.swing.JButton();
	        jButton9.setForeground(new Color(255, 255, 255));
	        jButton9.setBorder(BorderFactory.createLineBorder(new java.awt.Color(35,31,40)));
	        jButton9.setBackground(new java.awt.Color(35,31,40));
	        jButton9.setFont(new Font("Tahoma", Font.BOLD, 10));
	        jButton9.setBounds(162, 368, 98, 21);
	        jScrollPane1 = new javax.swing.JScrollPane();
	        jScrollPane1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
	        jScrollPane1.setBounds(28, 221, 364, 79);
	        jTextArea1 = new javax.swing.JTextArea();
	        jTextField1 = new javax.swing.JTextField();
	        jTextField1.setBounds(28, 317, 307, 21);
	        jTextField1.setBorder(BorderFactory.createLineBorder(Color.WHITE));
	        jButton10 = new javax.swing.JButton();
	        jButton10.setBorder(BorderFactory.createLineBorder(new java.awt.Color(255,97,139)));
	        jButton10.setBackground(new java.awt.Color(255,97,139));
	        jButton10.setBounds(347, 317, 47, 21);
	        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBackground(new java.awt.Color(48, 46, 43));
	        setForeground(new java.awt.Color(48, 46, 43));
	        setPreferredSize(new java.awt.Dimension(430,560));
	        setResizable(false);

	        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
	        jLayeredPane1.setLayout(jLayeredPane1Layout);
	        jLayeredPane1Layout.setHorizontalGroup(
	            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addGap(0, 100, Short.MAX_VALUE)
	        );
	        jLayeredPane1Layout.setVerticalGroup(
	            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addGap(0, 100, Short.MAX_VALUE)
	        );

	        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

	        jLabel2.setFont(new java.awt.Font("Tekton Pro Ext", 900, 24)); 
	        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
	        jLabel2.setText("Game Caro ");
	        jLabel2.setForeground(Color.white);

	        jButton1.setText("Tạo Phòng");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton1ActionPerformed(evt);
	            }
	        });

	        jButton3.setText("Bảng xếp hạng");
	        jButton3.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton3ActionPerformed(evt);
	            }
	        });

	        jButton4.setText("Tìm phòng");
	        jButton4.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton4ActionPerformed(evt);
	            }
	        });

	        jPanel1.setBackground(new java.awt.Color(35,31,40));

	        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel1.setText("NickName");
	        jLabel1.addAncestorListener(new javax.swing.event.AncestorListener() {
	            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
	            }
	            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
	                jLabel1AncestorMoved(evt);
	            }
	            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
	            }
	        });

	        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel3.setText("Số ván thắng");

	        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel4.setText("{day la Nick name}");

	        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel7.setText("{day la so van thang}");

	        jLabel8.setBackground(new java.awt.Color(204, 204, 204));

	        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel9.setText("{day la so van da choi}");

	        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel5.setText("Số ván đã chơi");

	        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel6.setText("Điểm");

	        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel10.setText("{day la diem}");

	        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel11.setText("Thứ hạng");

	        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel12.setText("{day la thu hang}");

	        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel13.setText("Tỉ lệ thắng");

	        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel14.setText("{day la ti le thang}");

	        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel15.setText("Số ván hòa");

	        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
	        jLabel16.setText("{day la so van hoa}");

	        jButton2.setText("Đăng xuất");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton2ActionPerformed(evt);
	            }
	        });

	        jButton5.setText("Thoát Game");
	        jButton5.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton5ActionPerformed(evt);
	            }
	        });

	        jButton6.setText("Chơi nhanh");
	        jButton6.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton6ActionPerformed(evt);
	            }
	        });

	        jButton7.setText("Chơi với máy");
	        jButton7.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton7ActionPerformed(evt);
	            }
	        });

	        jButton8.setText("Danh sách bạn bè");
	        jButton8.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton8ActionPerformed(evt);
	            }
	        });

	        jButton9.setText("Vào phòng");
	        jButton9.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton9ActionPerformed(evt);
	            }
	        });

	        jTextArea1.setColumns(20);
	        jTextArea1.setRows(5);
	        jTextArea1.setText("<<Tin nhắn và tin tức>>\n");
	        jScrollPane1.setViewportView(jTextArea1);

	        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
	            public void keyPressed(java.awt.event.KeyEvent evt) {
	                jTextField1KeyPressed(evt);
	            }
	        });

	        jButton10.setText("");
	        jButton10.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton10ActionPerformed(evt);
	            }
	        });
	        getContentPane().setLayout(null);
	        getContentPane().add(jLabel2);
	        getContentPane().add(jPanel1);
	        jPanel1.setLayout(null);
	        jPanel1.add(jLabel8);
	        jPanel1.add(jLabel3);
	        jPanel1.add(jLabel1);
	        jPanel1.add(jLabel5);
	        jPanel1.add(jLabel7);
	        jPanel1.add(jLabel9);
	        jPanel1.add(jLabel4);
	        jPanel1.add(jLabel15);
	        jPanel1.add(jLabel6);
	        jPanel1.add(jLabel13);
	        jPanel1.add(jLabel11);
	        jPanel1.add(jLabel10);
	        jPanel1.add(jLabel14);
	        jPanel1.add(jLabel12);
	        jPanel1.add(jLabel16);
	        getContentPane().add(jButton6);
	        getContentPane().add(jButton9);
	        getContentPane().add(jButton1);
	        getContentPane().add(jButton3);
	        getContentPane().add(jButton4);
	        getContentPane().add(jButton7);
	        getContentPane().add(jButton2);
	        getContentPane().add(jButton8);
	        getContentPane().add(jButton5);
	        getContentPane().add(jScrollPane1);
	        getContentPane().add(jTextField1);
	        getContentPane().add(jButton10);
	        
	        JLabel lblNewLabel = new JLabel("");
	        lblNewLabel.setIcon(new ImageIcon("assets\\bgr\\bg3.png"));
	        lblNewLabel.setBounds(0, 0, 416, 523);
	        getContentPane().add(lblNewLabel);

	        pack();
	    }

    private void jLabel1AncestorMoved(javax.swing.event.AncestorEvent evt) {
        
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Tạo Phòng"
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        int res = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn đặt mật khẩu cho phòng không?", "Tạo phòng", JOptionPane.YES_NO_OPTION);
        if(res==JOptionPane.YES_OPTION){
            Client.closeView(Client.View.HOMEPAGE);
            Client.openView(Client.View.CREATEROOMPASSWORD);
        }
        else if(res==JOptionPane.NO_OPTION){
            try {
            Client.socketHandle.write("create-room,");
            Client.closeView(Client.View.HOMEPAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        } 
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Tìm phòng"
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Client.closeView(Client.View.HOMEPAGE);
            Client.openView(Client.View.ROOMLIST);
            Client.socketHandle.write("view-room-list,");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Bảng xếp hạng"
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.openView(Client.View.RANK);
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Đăng xuất"
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Client.socketHandle.write("offline,"+Client.user.getID());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
        Client.closeView(Client.View.HOMEPAGE);
        Client.openView(Client.View.LOGIN);
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Thoát Game"
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Danh sách bạn bè"
    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.closeView(Client.View.HOMEPAGE);
        Client.openView(Client.View.FRIENDLIST);
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Chơi nhanh"
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.closeView(Client.View.HOMEPAGE);
        Client.openView(Client.View.FINDROOM);
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Chơi với máy"
    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.openView(Client.View.GAMEAI);
    }

 // Xử lý sự kiện khi người dùng nhấn nút "Vào phòng"
    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
        Client.openView(Client.View.ROOMNAMEFRM);
    }

 // Xử lý sự kiện khi người dùng nhấn nút gửi tin nhắn
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {
        sendMessage();
    }

 // Xử lý sự kiện khi người dùng nhấn phím trong ô nhập tin nhắn
    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {
        if(evt.getKeyCode() == 10){
            sendMessage();
        }
    }

    private void sendMessage(){
        try {
            if (jTextField1.getText().isEmpty()) {
                throw new Exception("Vui lòng nhập nội dung tin nhắn");
            }
            String temp = jTextArea1.getText();
            temp += "Tôi: " + jTextField1.getText() + "\n";
            jTextArea1.setText(temp);
            Client.socketHandle.write("chat-server," + jTextField1.getText());
            jTextField1.setText("");
            jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, ex.getMessage());
        }
    }
    
 // Thêm tin nhắn vào vùng hiển thị tin nhắn
    public void addMessage(String message){
        String temp = jTextArea1.getText();
        temp+=message+"\n";
        jTextArea1.setText(temp);
        jTextArea1.setCaretPosition(jTextArea1.getDocument().getLength());
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
}