package controller;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Point;

public class CaroActionListener implements ActionListener{
	
	private Point point; //để lưu trữ thông tin vị trí.
	
	public CaroActionListener(Point p) {
		point = p;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}
}