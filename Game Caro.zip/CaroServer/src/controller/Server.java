package controller;

import view.Admin;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

//Lớp Server quản lý các luồng ServerThread, giao diện người dùng Admin và giao tiếp với client thông qua ServerSocket.

public class Server {

    public static volatile ServerThreadBus serverThreadBus;// Đối tượng ServerThreadBus để quản lý các luồng ServerThread.
    public static Socket socketOfServer;// Đối tượng Socket của server.
    public static int ID_room;// ID phòng.
    public static volatile Admin admin;// Đối tượng Admin để quản lý giao diện người dùng.

    public static void main(String[] args) {
        ServerSocket listener = null;
        serverThreadBus = new ServerThreadBus();// Khởi tạo đối tượng ServerThreadBus.
        System.out.println("Server is waiting to accept user...");
        int clientNumber = 0;
        ID_room = 100;
        
        try {
            listener = new ServerSocket(8888);// Tạo một ServerSocket để lắng nghe các yêu cầu kết nối từ client.
        } catch (IOException e) {
            System.out.println(e);
            System.exit(1);
        }
        ThreadPoolExecutor executor = new ThreadPoolExecutor(
                10, // corePoolSize - số lượng luồng tối thiểu được duy trì trong ThreadPoolExecutor.
                100, // maximumPoolSize - số lượng luồng tối đa được tạo ra trong ThreadPoolExecutor.
                10, // thread timeout - thời gian chờ tối đa của một luồng trong ThreadPoolExecutor trước khi bị hủy bỏ.
                TimeUnit.SECONDS,// Đơn vị thời gian cho thread timeout.
                new ArrayBlockingQueue<>(8) // queueCapacity - giới hạn số yêu cầu đợi trong ThreadPoolExecutor.
        );
        admin = new Admin();// Khởi tạo đối tượng Admin.
        admin.run();// Chạy giao diện người dùng Admin.
        try {
            while (true) {
                // Chấp nhận một yêu cầu kết nối từ phía Client.
                // Đồng thời nhận được một đối tượng Socket tại server.
                socketOfServer = listener.accept();
                System.out.println(socketOfServer.getInetAddress().getHostAddress());
                ServerThread serverThread = new ServerThread(socketOfServer, clientNumber++);
                serverThreadBus.add(serverThread);// Thêm đối tượng ServerThread vào ServerThreadBus để quản lý.
                System.out.println("Số thread đang chạy là: "+serverThreadBus.getLength());
                executor.execute(serverThread);  // Thực thi ServerThread trong ThreadPoolExecutor.
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                listener.close();// Đóng ServerSocket.
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}