package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


//Lớp ServerThreadBus trong đoạn mã trên là một lớp quản lý danh sách các luồng máy chủ (ServerThread). 
//Nó cung cấp các phương thức để thêm, xóa, truy xuất và gửi tin nhắn đến các luồng máy chủ trong danh sách.

public class ServerThreadBus {
    private List<ServerThread> listServerThreads;

    public List<ServerThread> getListServerThreads() {	//Phương thức getter để trả về danh sách các luồng máy chủ.
        return listServerThreads;
    }

    public ServerThreadBus() {	// constructor
        listServerThreads = new ArrayList<>();
    }

    public void add(ServerThread serverThread){	//Phương thức để thêm một luồng máy chủ vào danh sách.
        listServerThreads.add(serverThread);
    }
    
    //Phương thức dùng để gửi tin nhắn multicast (gửi tới tất cả các luồng máy chủ trong danh sách).
    public void mutilCastSend(String message){ //like sockets.emit in socket.io
    	//Lặp qua mỗi luồng máy chủ trong danh sách.
    	for(ServerThread serverThread : Server.serverThreadBus.getListServerThreads()){
            try {
                serverThread.write(message);	//Gọi phương thức write trên serverThread để ghi message đến luồng máy chủ.
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    //Phương thức dùng để gửi tin nhắn broadcast (gửi tới tất cả các luồng máy chủ trong danh sách, trừ luồng có id tương ứng).
    public void boardCast(int id, String message){
    	// Lặp qua mỗi luồng máy chủ trong danh sách.
    	for(ServerThread serverThread : Server.serverThreadBus.getListServerThreads()){
            if (serverThread.getClientNumber() == id) {	//Kiểm tra nếu clientNumber của serverThread trùng với id, thì bỏ qua luồng đó.
                continue;
            } else {	//Nếu clientNumber không trùng với id, thì gửi message đến luồng máy chủ đó.
                try {
                    serverThread.write(message);	//Gọi phương thức write trên serverThread để ghi message đến luồng máy chủ.
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    // Phương thức để lấy số lượng luồng máy chủ trong danh sách.
    public int getLength(){
        return listServerThreads.size();
    }
    
    // Phương thức để gửi tin nhắn tới một người dùng có id tương ứng.
    public void sendMessageToUserID(int id, String message){
        for(ServerThread serverThread : Server.serverThreadBus.getListServerThreads()){
            if(serverThread.getUser().getID()==id){	//Kiểm tra nếu ID của người dùng liên quan đến serverThread trùng với id, thì gửi message đến luồng máy chủ đó.
                try {
                    serverThread.write(message);
                    break;
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    // Phương thức để lấy luồng máy chủ dựa trên ID của người dùng liên quan.
    public ServerThread getServerThreadByUserID(int ID){
        for(int i=0; i<Server.serverThreadBus.getLength(); i++){
            if(Server.serverThreadBus.getListServerThreads().get(i).getUser().getID()==ID){	// Kiểm tra nếu ID của người dùng liên quan đến serverThread trùng với ID đưa vào, thì trả về serverThread đó.
                return Server.serverThreadBus.listServerThreads.get(i);
            }
        }
        return null;
    }
    
    // Phương thức để xóa một luồng máy chủ dựa trên id của client.
    public void remove(int id){
        for(int i=0; i<Server.serverThreadBus.getLength(); i++){
            if(Server.serverThreadBus.getListServerThreads().get(i).getClientNumber()==id){	//Kiểm tra nếu clientNumber của serverThread trùng với id đưa vào, thì xóa serverThread đó khỏi danh sách.
                Server.serverThreadBus.listServerThreads.remove(i);	//Xóa serverThread tại vị trí i khỏi danh sách.
            }
        }
    }
}