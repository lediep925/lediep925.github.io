/**
 * 
 */
/**
 * @author Jullia
 *
 */
module CaroServer {
	requires java.sql;
	requires java.desktop;
}