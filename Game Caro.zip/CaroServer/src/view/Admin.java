package view;

import dao.UserDAO;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import model.User;
import controller.Room;
import controller.Server;
import controller.ServerThread;

public class Admin extends javax.swing.JFrame implements Runnable{
    private UserDAO userDAO;
    public Admin() {
        initComponents();
     // Cấu hình giao diện
        this.setIconImage(new ImageIcon("assets/image/server-config-icon.png").getImage());
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setBackground(new Color(255,163,188));
        jTextArea1.setEditable(false);
        jTextArea2.setEditable(false);
        userDAO = new UserDAO();
    }
    @SuppressWarnings("unchecked")
    private void initComponents() {
    	// Cấu hình các thành phần giao diện và sự kiện
        jTextField2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jTextField3 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setText("Xem danh sách luồng");
        jButton1.setBackground(new Color(255,163,188));
        jButton1.setForeground(Color.white);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Xem danh sách phòng");
        jButton2.setBackground(new Color(255,163,188));
        jButton2.setForeground(Color.white);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new Color(255,163,188));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jLabel1.setForeground(Color.white);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Admin");
        

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });

//        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jButton3.setText("Phát thông báo");
        jButton3.setBackground(new Color(255,163,188));
        jButton3.setForeground(Color.white);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

//        jButton4.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jButton4.setText("Ban");
        jButton4.setBackground(new Color(255,163,188));
        jButton4.setForeground(Color.white);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

//        jButton5.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jButton5.setText("Cảnh cáo");
        jButton5.setBackground(new Color(255,163,188));
        jButton5.setForeground(Color.white);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

//        jButton6.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jButton6.setText("Huỷ Ban");
        jButton6.setBackground(new Color(255,163,188));
        jButton6.setForeground(Color.white);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jComboBox1.setBackground(new Color(255,255,255));
        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 11));
//        jComboBox1.setForeground(new Color(255,97,139));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chọn lý do", "Ngôn ngữ thô tục - xúc phạm người khác", "Spam đăng nhập", "Sử dụng game với mục đích xấu", "Phát hiện rò rỉ bảo mật - tài khoản tạm thời bị khoá để kiểm tra thêm" }));
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                .addGap(61, 61, 61))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(31, 31, 31)
                            .addComponent(jScrollPane2))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(30, 30, 30)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton6)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }

 // Hiển thị danh sách luồng (server threads)
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        String res = "";
        String room="";
        int i=1;
        for(ServerThread serverThread : Server.serverThreadBus.getListServerThreads()){
            if(serverThread.getRoom()==null)
                room = null;
            else room =""+ serverThread.getRoom().getID();
            if(serverThread.getUser()!=null){
                 res+=i+". Client-number: "+serverThread.getClientNumber()+", User-ID: "+serverThread.getUser().getID()+", Room: "+room+"\n";
            }
            else{
                res+=i+". Client-number: "+serverThread.getClientNumber()+", User-ID: null, Room: "+room+"\n";
            }
            i++;
        }
        jTextArea1.setText(res);
    }

 // Hiển thị danh sách phòng (rooms)
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        String res = "";
        int i=1;
        for (ServerThread serverThread : Server.serverThreadBus.getListServerThreads()) {
            Room room1 = serverThread.getRoom();
            String listUser = "List user ID: ";
            if (room1 != null) {
                if (room1.getNumberOfUser() == 1) {
                    listUser += room1.getUser1().getUser().getID();
                } else {
                    listUser += room1.getUser1().getUser().getID() + ", " + room1.getUser2().getUser().getID();
                }
                res +=i+ ". Room_ID: " + room1.getID() + ", Number of player: " + room1.getNumberOfUser() + ", " + listUser + "\n";
                i++;
            }
            
        }
        jTextArea1.setText(res);
    }

 // Gửi thông báo đến tất cả người dùng
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        sendMessage();
    }

 // Xử lý sự kiện nhấn Enter trong ô nhập tin nhắn
    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {
        if(evt.getKeyCode()==10){
            sendMessage();
        }
    }

 // Xử lý sự kiện BAN user
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            if(jTextField3.getText().length()==0){
                JOptionPane.showMessageDialog(rootPane, "Vui lòng nhập ID của User");
                return;
            }
            if(jComboBox1.getSelectedIndex()<1){
                JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn lý do");
                return;
            }
            int userId = Integer.parseInt(jTextField3.getText());
            User user = new User();
            user.setID(userId);
            userDAO.updateBannedStatus(user, true);
            ServerThread serverThread = Server.serverThreadBus.getServerThreadByUserID(userId);
            serverThread.write("banned-notice,"+jComboBox1.getSelectedItem());
            if(serverThread.getRoom()!=null){
                Room room = serverThread.getRoom();
                ServerThread competitorThread = room.getCompetitor(serverThread.getClientNumber());
                room.setUsersToNotPlaying();
                if(competitorThread!=null){
                    room.decreaseNumberOfGame();
                    competitorThread.write("left-room,");
                    competitorThread.setRoom(null);
                }
                serverThread.setRoom(null);
            }
            Server.admin.addMessage("User có ID "+ userId+" đã bị BAN");
            serverThread.setUser(null);
            Server.serverThreadBus.boardCast(-1, "chat-server,"+"User có ID "+ userId+" đã bị BAN");
            JOptionPane.showMessageDialog(rootPane, "Đã BAN user "+userId);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Có lỗi xảy ra");
        }
    }

 // Xử lý sự kiện huỷ BAN user
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            if(jTextField3.getText().length()==0){
                JOptionPane.showMessageDialog(rootPane, "Vui lòng nhập ID của User");
                return;
            }
            int userId = Integer.parseInt(jTextField3.getText());
            User user = new User();
            user.setID(userId);
            userDAO.updateBannedStatus(user, false);
            jTextField3.setText("");
            JOptionPane.showMessageDialog(rootPane, "Đã huỷ BAN user "+userId);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Có lỗi xảy ra");
        }
    }

 // Xử lý sự kiện cảnh cáo user
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            if(jTextField3.getText().length()==0){
                JOptionPane.showMessageDialog(rootPane, "Vui lòng nhập ID của User");
                return;
            }
            if(jComboBox1.getSelectedIndex()<1){
                JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn lý do");
                return;
            }
            int userId = Integer.parseInt(jTextField3.getText());
            Server.serverThreadBus.sendMessageToUserID(userId, "warning-notice,"+jComboBox1.getSelectedItem());
            JOptionPane.showMessageDialog(rootPane, "Đã cảnh cáo user "+userId);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Có lỗi xảy ra");
        }
    }
    
 // Gửi tin nhắn thông báo từ máy chủ đến tất cả người dùng
    private void sendMessage(){
        String message = jTextField1.getText();
        if(message.length()==0) return;
        String temp = jTextArea2.getText();
        temp+= "Thông báo từ máy chủ : "+message+"\n";
        jTextArea2.setText(temp);
        jTextArea2.setCaretPosition(jTextArea2.getDocument().getLength());
        Server.serverThreadBus.boardCast(-1,"chat-server,Thông báo từ máy chủ : "+ message);
        jTextField1.setText("");
    }
    
 // Thêm tin nhắn vào khung chat
    public void addMessage(String message) {
        String tmp = jTextArea2.getText();
        tmp=tmp+message+"\n";
        jTextArea2.setText(tmp);
        jTextArea2.setCaretPosition(jTextArea1.getDocument().getLength());
    }

    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    public static javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;

    @Override
    public void run() {
        new Admin().setVisible(true);
    }
}